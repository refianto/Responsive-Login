<!DOCTYPE html>
<html>
<head>
	<title>L091n</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0\css\font-awesome.min.css">
	<style type="text/css">
		body{
			margin: 0;
			padding: 0;
			background-color: #064079;
		}
		.isi{
			background-color: #ffad33;
			max-width: 350px;
			max-height: 300px;
			margin: auto;
			margin-top: 20%;
			text-align: center;
			padding-top: 10px;
			padding-bottom: 30px;
			border-radius: 10px;
		}
		.use{
			width: 100%;
			max-width: 300px;
			border: 1px solid #808080;
			border-radius: 10px;
			margin: 8px 0 0;
			text-align: center;
		}
		.login{
			width: 100%;
			background-color: #064079;
			color: #ffffff;
			text-align: center;
			max-width: 300px;
			border:none;
			margin: 8px 0 0 0;
			border-radius: 10px;
		}
		.daftar{
			width: 100%;
			background-color: #ffffff;
			border:1px solid #064079;
			color: #064079;
			max-width: 300px;
			border-radius: 10px;
			text-align: center;
			margin: 20px 0 0 0 ;
			font-family: arial;
		}
		.lingkaran{
			border-radius: 100%;
			width: 100px;
			height: 100px;
			text-align: center;
			background-color: #ffffff;
			margin: auto;
			margin-top: -70px;
		}
		p{
			color: #ffffff;
		}
		a .left{
			margin-left: auto;
		}
		a .right{
			margin-right: auto;
		}
	</style>
</head>
<body>

<div class="isi">
	<div class="lingkaran">
		<i class="fa fa-user fa-5x" aria-hidden="true" style="color: #064079; margin-top: 14px"></i>
	</div>
	<form>
		<input type="text" name="username" class="use" placeholder="Username" style="margin-top: 20px;">
		<input type="password" name="password" class="use" placeholder="Password">
		<input type="submit" name="login" value="Login" class="login"><br>
		<a href="#" class="left">Lupa Kata Sandi?</a>
		<input type="submit" name="daftar" value="Daftar" class="daftar">
	</form>

</div>

</body>
</html>